import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import pl.edu.agh.to.lab4.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FinderTest {
    private ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    private PrintStream originalOut;
    PersonDatabase personDatabase = new PersonDatabase();
    PrisonersDatabase prisonersDatabase = new PrisonersDatabase();
    private Finder suspectFinder;

    public FinderTest() {
        List<SuspectAggregate> databases = new ArrayList<>();
        databases.add(personDatabase);
        databases.add(prisonersDatabase);
        suspectFinder = new Finder(new CompositeAggregate(databases));
    }

    @Test
    public void testDisplayingNotJailedPrisoner() {
        addPrisoner("Wiezeienie stanowe", new Prisoner("Krzysztof", "Nowak", "82102587321", 2010, 3));
        suspectFinder.display(new NameSearchStrategy("Krzysztof"));
        assertContentIsDisplayed("Krzysztof Nowak");
    }

    @Test
    public void testDisplayingSuspectedPerson() {
        personDatabase.addPerson("Monika", "Ala", 24);
        suspectFinder.display(new NameSearchStrategy("Monika"));
        assertContentIsDisplayed("Monika Ala");
    }

    @Test
    public void testNotDisplayingTooYoungPerson() {
        personDatabase.addPerson("Ola", "Kowalska", 10);
        suspectFinder.display(new NameSearchStrategy("Ola"));
        assertContentIsNotDisplayed("Ola Kowalska");
    }

    @Test
    public void testNotDisplayingJailedPrisoner() {
        personDatabase.addPerson("Paweł", "Kowal", 18);
        addPrisoner("Wiezeienie krakowskie", new Prisoner("Paweł", "Kowalski", "02233087654", 2020, 5));
        suspectFinder.display(new NameSearchStrategy("Jan"));
        assertContentIsNotDisplayed("Paweł Kowalski" );
    }

    private void assertContentIsDisplayed(String expectedContent) {
        assertTrue("Application did not contain expected content: " + outContent.toString(), outContent.toString()
                .contains(expectedContent));
    }

    private void assertContentIsNotDisplayed(String expectedContent) {
        assertFalse("Application did contain expected content although it should not: " + outContent.toString(), outContent.toString()
                .contains(expectedContent));
    }

    @Before
    public void redirectSystemOut() {
        originalOut = System.out;
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void resetSystemOut() {
        System.setOut(originalOut);
    }

    private void addPrisoner(String category, Prisoner news) {
        if (!prisonersDatabase.getPrisoners().containsKey(category))
            prisonersDatabase.getPrisoners().put(category, new ArrayList<Prisoner>());
        prisonersDatabase.addPrisoner(category, news);
    }
}
