import org.junit.Test;
import pl.edu.agh.to.lab4.Prisoner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PrisonerTest {
    @Test
    public void testPrisonerIsInJail() {
        Prisoner news = new Prisoner("Paweł", "Kowalski", "02233087654", 2020, 5);
        assertFalse(news.canBeSuspected());
    }

    @Test
    public void testPrisonerHasBeenReleasedFromJail() {
        Prisoner news = new Prisoner("Jan", "Trąba", "80210454337", 2001, 18);
        assertTrue(news.canBeSuspected());
    }
}
