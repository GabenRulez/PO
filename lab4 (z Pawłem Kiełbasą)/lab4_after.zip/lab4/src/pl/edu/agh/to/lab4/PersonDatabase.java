package pl.edu.agh.to.lab4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class PersonDatabase implements SuspectAggregate {

    private final Collection<Person> cracovPeople = new ArrayList<Person>();

    public PersonDatabase() {
    }

    @Override
    public Iterator<Suspect> iterator(SearchStrategy searchStrategy) {
        return new SuspectIterator(cracovPeople.iterator(), searchStrategy);
    }

    public void generateData() {
        addPerson("Jan", "Kowalski", 30);
        addPerson("Janusz", "Krakowski", 30);
        addPerson("Janusz", "Mlodociany", 10);
        addPerson("Kasia", "Kosinska", 19);
        addPerson("Piotr", "Zgredek", 29);
        addPerson("Tomek", "Gimbus", 14);
        addPerson("Janusz", "Gimbus", 15);
        addPerson("Alicja", "Zaczarowana", 22);
        addPerson("Janusz", "Programista", 77);
        addPerson("Pawel", "Pawlowicz", 32);
        addPerson("Krzysztof", "Mendel", 30);
    }

    public Collection<Person> getAllCracovPeople() {
        return this.cracovPeople;
    }

    public void addPerson(String firstName, String lastName, int age) {
        cracovPeople.add(new Person(firstName, lastName, age));
    }
}
