package pl.edu.agh.to.lab4;

import java.util.ArrayList;
import java.util.List;

public class Application {

    public static void main(String[] args) {
        PersonDatabase personDatabase = new PersonDatabase();
        personDatabase.generateData();
        PrisonersDatabase prisonerDatabase = new PrisonersDatabase();
        prisonerDatabase.generateInitialData();
        StudentDatabase studentDatabase = new StudentDatabase();
        studentDatabase.generateData();

        List<SuspectAggregate> databases = new ArrayList<>();
        databases.add(personDatabase);
        databases.add(prisonerDatabase);
        databases.add(studentDatabase);

        Finder suspects = new Finder(new CompositeAggregate(databases));

        suspects.display(new NameSearchStrategy("Janusz"));
        suspects.display(new AgeSearchStrategy(30));
        List<SearchStrategy> strategies = new ArrayList<>();
        strategies.add(new NameSearchStrategy("Tomek"));
        strategies.add(new AgeSearchStrategy(14));
        suspects.display(new CompositeSearchStrategy(strategies));
    }
}
