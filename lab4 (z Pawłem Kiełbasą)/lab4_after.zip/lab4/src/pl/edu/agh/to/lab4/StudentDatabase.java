package pl.edu.agh.to.lab4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class StudentDatabase implements SuspectAggregate {
    private final Collection<Student> students = new ArrayList<Student>();

    public StudentDatabase() { }

    @Override
    public Iterator<Suspect> iterator(SearchStrategy searchStrategy) {
        return new SuspectIterator(students.iterator(), searchStrategy);
    }

    public void generateData() {
        addStudent("Bro", "Fida", "832782");
        addStudent("Wadim", "Kosman", "332474");
        addStudent("Remigiusz", "Pylka", "845446");
        addStudent("Konrad", "Kasza", "234523");
    }

    public Collection<Student> getStudents() {
        return students;
    }

    public void addStudent(String firstName, String lastName, String index) {
        students.add(new Student(firstName, lastName, index));
    }
}
