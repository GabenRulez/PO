package pl.edu.agh.to.lab4;

public interface SearchStrategy {
    boolean filter(Suspect suspect);
}
