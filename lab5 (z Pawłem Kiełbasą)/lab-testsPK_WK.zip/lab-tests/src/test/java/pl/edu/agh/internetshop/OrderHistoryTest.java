package pl.edu.agh.internetshop;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;

import static org.mockito.Mockito.mock;

public class OrderHistoryTest {
    private Order getMockOrder1() {
        Order order = mock(Order.class);
        List<Product> productList = Arrays.asList(
                new Product("Chipsy", BigDecimal.valueOf(4.49), BigDecimal.valueOf(0.5)),
                new Product("Pepsi", BigDecimal.valueOf(5.39), BigDecimal.valueOf(0.39))
        );
        given(order.getProducts()).willReturn(productList);
        return order;
    }

    @Test
    public void productIsInTheOrder() {
        // given
        Order order = getMockOrder1();
        // when
        SearchStrategyProductName searchStrategy = new SearchStrategyProductName("Chipsy");
        // then
        assertTrue(searchStrategy.filter(order));
    }

    @Test
    public void productIsNotInTheOrder() {
        // given
        Order order = getMockOrder1();
        // when
        SearchStrategyProductName searchStrategy = new SearchStrategyProductName("mieso");
        // then
        assertFalse(searchStrategy.filter(order));
    }






    @Test
    public void sameSurname() {
        // given
        Order order = mock(Order.class);
        given(order.getPayerSurname()).willReturn("Surname");
        // when
        SearchStrategySurname searchStrategy = new SearchStrategySurname("Surname");
        // then
        assertTrue(searchStrategy.filter(order));
    }

    @Test
    public void notTheSameSurname() {
        // given
        Order order = mock(Order.class);
        given(order.getPayerSurname()).willReturn("notSurname");
        // when
        SearchStrategySurname searchStrategy = new SearchStrategySurname("Surname");
        // then
        assertFalse(searchStrategy.filter(order));
    }

    @Test
    public void surnameIsNull() {
        // given
        Order order = mock(Order.class);
        given(order.getPayerSurname()).willReturn(null);
        // when
        SearchStrategySurname searchStrategy = new SearchStrategySurname("Surname");
        // then
        assertFalse(searchStrategy.filter(order));
    }





    private Order getMockOrder2() {
        Order order = mock(Order.class);
        given(order.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));
        return order;
    }

    @Test
    public void samePrice() {
        // given
        Order order = getMockOrder2();
        // when
        SearchStrategyPrice searchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(10));
        // then
        assertTrue(searchStrategy.filter(order));
    }

    @Test
    public void notTheSamePrice() {
        // given
        Order order = getMockOrder2();
        // when
        SearchStrategyPrice searchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(9));
        // then
        assertFalse(searchStrategy.filter(order));
    }






    private Order getMockOrder3() {
        Order order = mock(Order.class);
        List<Product> productList = Arrays.asList(
                new Product("Chipsy", BigDecimal.valueOf(4.49), BigDecimal.valueOf(0.5)),
                new Product("Pepsi", BigDecimal.valueOf(5.39), BigDecimal.valueOf(0.39))
        );
        given(order.getProducts()).willReturn(productList);
        given(order.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));
        given(order.getPayerSurname()).willReturn("Surname");
        return order;
    }

    @Test
    public void sameParameters() {
        // given
        Order order = getMockOrder3();
        SearchStrategy productNameSearchStrategy = new SearchStrategyProductName("Chipsy");
        SearchStrategy payersSurnameSearchStrategy = new SearchStrategySurname("Surname");
        SearchStrategy totalPriceSearchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(10));

        // when
        SearchStrategyComposite searchStrategy = new SearchStrategyComposite(
                Arrays.asList(productNameSearchStrategy, payersSurnameSearchStrategy, totalPriceSearchStrategy));

        // then
        assertTrue(searchStrategy.filter(order));
    }

    @Test
    public void sameParametersButProductName() {
        // given
        Order order = getMockOrder3();
        SearchStrategy productNameSearchStrategy = new SearchStrategyProductName("mieso");
        SearchStrategy payersSurnameSearchStrategy = new SearchStrategySurname("Surname");
        SearchStrategy totalPriceSearchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(10));

        // when
        SearchStrategyComposite searchStrategy = new SearchStrategyComposite(
                Arrays.asList(productNameSearchStrategy, payersSurnameSearchStrategy, totalPriceSearchStrategy));

        // then
        assertFalse(searchStrategy.filter(order));
    }

    @Test
    public void sameParametersButSurname() {
        // given
        Order order = getMockOrder3();
        SearchStrategy productNameSearchStrategy = new SearchStrategyProductName("Pepsi");
        SearchStrategy payersSurnameSearchStrategy = new SearchStrategySurname("notSurname");
        SearchStrategy totalPriceSearchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(10));

        // when
        SearchStrategyComposite searchStrategy = new SearchStrategyComposite(
                Arrays.asList(productNameSearchStrategy, payersSurnameSearchStrategy, totalPriceSearchStrategy));

        // then
        assertFalse(searchStrategy.filter(order));
    }

    @Test
    public void sameParametersButPrice() {
        // given
        Order order = getMockOrder3();
        SearchStrategy productNameSearchStrategy = new SearchStrategyProductName("Pepsi");
        SearchStrategy payersSurnameSearchStrategy = new SearchStrategySurname("Surname");
        SearchStrategy totalPriceSearchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(9));

        // when
        SearchStrategyComposite searchStrategy = new SearchStrategyComposite(
                Arrays.asList(productNameSearchStrategy, payersSurnameSearchStrategy, totalPriceSearchStrategy));

        // then
        assertFalse(searchStrategy.filter(order));
    }











    @Test
    void getFewOrdersFromOrderHistory() {
        // given
        List<Order> orders = Arrays.asList(mock(Order.class), mock(Order.class));

        // when
        OrderHistory OrderHistory = new OrderHistory(orders);

        // then
        assertEquals(2, OrderHistory.getOrders().size());
        assertSame(orders.get(0), OrderHistory.getOrders().get(0));
        assertSame(orders.get(1), OrderHistory.getOrders().get(1));
    }
    

    @Test
    void getSearchResultsWithProductName() {
        // given
        Product product_0 = mock(Product.class);
        Product product_1 = mock(Product.class);
        Product product_2 = mock(Product.class);
        Product product_3 = mock(Product.class);

        given(product_0.getName()).willReturn("mieso");
        given(product_1.getName()).willReturn("befsztyk");
        given(product_2.getName()).willReturn("kaszanka");
        given(product_3.getName()).willReturn("pasztetowa");

        Order order = mock(Order.class);
        Order order1 = mock(Order.class);
        Order order2 = mock(Order.class);

        given(order.getProducts()).willReturn(Arrays.asList(product_0, product_1));
        given(order1.getProducts()).willReturn(Arrays.asList(product_1, product_3));
        given(order2.getProducts()).willReturn(Arrays.asList(product_0, product_1, product_2, product_3));

        SearchStrategy searchStrategy = new SearchStrategyProductName("mieso");

        // when
        OrderHistory OrderHistory = new OrderHistory(Arrays.asList(order, order1, order2));

        // then
        assertEquals(2, OrderHistory.getSearchResult(searchStrategy).size());
        assertSame(order, OrderHistory.getSearchResult(searchStrategy).get(0));
        assertSame(order2, OrderHistory.getSearchResult(searchStrategy).get(1));
    }

    @Test
    void getSearchResultsWithSurname() {
        // given
        Order order = mock(Order.class);
        Order order1 = mock(Order.class);
        Order order2 = mock(Order.class);

        given(order.getPayerSurname()).willReturn("Surname1");
        given(order1.getPayerSurname()).willReturn("Surname2");
        given(order2.getPayerSurname()).willReturn("Surname1");

        SearchStrategy searchStrategy = new SearchStrategySurname("Surname1");

        // when
        OrderHistory OrderHistory = new OrderHistory(Arrays.asList(order, order1, order2));

        // then
        assertEquals(2, OrderHistory.getSearchResult(searchStrategy).size());
        assertSame(order, OrderHistory.getSearchResult(searchStrategy).get(0));
        assertSame(order2, OrderHistory.getSearchResult(searchStrategy).get(1));
    }

    @Test
    void getSearchResultsWithPrice() {
        // given
        Order order = mock(Order.class);
        Order order1 = mock(Order.class);
        Order order2 = mock(Order.class);

        given(order.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));
        given(order1.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(20));
        given(order2.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));

        SearchStrategy searchStrategy = new SearchStrategyPrice(BigDecimal.valueOf(10));

        // when
        OrderHistory OrderHistory = new OrderHistory(Arrays.asList(order, order1, order2));

        // then
        assertEquals(2, OrderHistory.getSearchResult(searchStrategy).size());
        assertSame(order, OrderHistory.getSearchResult(searchStrategy).get(0));
        assertSame(order2, OrderHistory.getSearchResult(searchStrategy).get(1));
    }

    @Test
    void getCompositeSearchResults() {
        // given
        Product product = mock(Product.class);
        Product product_1 = mock(Product.class);
        Product product_2 = mock(Product.class);
        Product product_3 = mock(Product.class);

        given(product.getName()).willReturn("mieso");
        given(product_1.getName()).willReturn("befsztyk");
        given(product_2.getName()).willReturn("kaszanka");
        given(product_3.getName()).willReturn("pasztetowa");

        Order order = mock(Order.class);
        Order order1 = mock(Order.class);
        Order order2 = mock(Order.class);

        given(order.getProducts()).willReturn(Arrays.asList(product, product_1, product_3));
        given(order1.getProducts()).willReturn(Arrays.asList(product_1, product_3));
        given(order2.getProducts()).willReturn(Arrays.asList(product, product_1, product_2, product_3));

        given(order.getPayerSurname()).willReturn("Surname1");
        given(order1.getPayerSurname()).willReturn("Surname2");
        given(order2.getPayerSurname()).willReturn("Surname1");

        given(order.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(20));
        given(order1.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));
        given(order2.getPriceWithTaxes()).willReturn(BigDecimal.valueOf(10));

        SearchStrategy searchStrategy = new SearchStrategyComposite(Arrays.asList(
                new SearchStrategyProductName("pasztetowa"),
                new SearchStrategySurname("Surname1"),
                new SearchStrategyPrice(BigDecimal.valueOf(10))
        ));

        // when
        OrderHistory OrderHistory = new OrderHistory(Arrays.asList(order, order1, order2));

        // then
        assertEquals(1, OrderHistory.getSearchResult(searchStrategy).size());
        assertSame(order2, OrderHistory.getSearchResult(searchStrategy).get(0));
    }

    @Test
    public void searchStrategyIsNull() {
        // given

        // when
        OrderHistory OrderHistory = new OrderHistory(Arrays.asList(mock(Order.class), mock(Order.class)));

        // then
        assertThrows(NullPointerException.class, () -> OrderHistory.getSearchResult(null));
    }
    
}
