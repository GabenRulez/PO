package pl.edu.agh.internetshop;

import java.util.List;

public class SearchStrategyProductName implements SearchStrategy {
    private String name;

    public SearchStrategyProductName(String name) {
        this.name = name;
    }

    @Override
    public boolean filter(Order order) {
        List<Product> products = order.getProducts();
        for (Product product: products) {
            if (product.getName().equals(this.name)) {
                return true;
            }
        }
        return false;
    }
}
