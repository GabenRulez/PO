package pl.edu.agh.internetshop;

import org.graalvm.compiler.nodeinfo.StructuralInput;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class OrderHistory {
    private List<Order> zamowienia = new ArrayList<Order>();

    public OrderHistory(List<Order> orders){
        this.zamowienia = Objects.requireNonNull(orders, "Zamowienia nie moga byc null");
        this.zamowienia.forEach((p) -> Objects.requireNonNull(p, "Zamowienie nie moze byc null"));
    }

    public void addOrder(Order order){
        this.zamowienia.add(order);
    }

    public List<Order> getOrders(){
        return this.zamowienia;
    }

    public List<Order> getSearchResult(SearchStrategy searchStrategy){
        List<Order> temp_zamowienia = new ArrayList<>();
        for(Order order : this.zamowienia){
            if(searchStrategy.filter(order)){
                temp_zamowienia.add(order);
            }
        }
        return temp_zamowienia;
    }

}
