package pl.edu.agh.internetshop;

public interface SearchStrategy {
    boolean filter(Order order);
}

