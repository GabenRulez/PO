package pl.edu.agh.internetshop;

public class SearchStrategySurname implements SearchStrategy {
    private String surname;

    public SearchStrategySurname(String surname) {
        this.surname = surname;
    }

    @Override
    public boolean filter(Order order) {
        if (order.getPayerSurname() != null) {
            return order.getPayerSurname().equals(this.surname);
        }
        return false;
    }
}

