package pl.edu.agh.internetshop;

import java.math.BigDecimal;

public class SearchStrategyPrice implements SearchStrategy {
    BigDecimal price;

    public SearchStrategyPrice(BigDecimal price) {
        this.price = price;
    }

    @Override
    public boolean filter(Order order) {
        return order.getPriceWithTaxes().compareTo(this.price) == 0;
    }
}
