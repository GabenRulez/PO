package pl.edu.agh.internetshop;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static pl.edu.agh.internetshop.util.CustomAssertions.assertBigDecimalCompareValue;

public class OrderTest {

	private Order getOrderWithMockedProduct() {
		Product product = mock(Product.class);
		return new Order(Collections.singletonList(product));
	}
	@Test
	public void productsListIsNull() {
		// when then
		assertThrows(NullPointerException.class, () -> new Order(null));
	}

	@Test
	public void listProductIsNull() {
		// given
		List<Product> products = Arrays.asList(mock(Product.class), null);

		// when then
		assertThrows(NullPointerException.class, () -> new Order(products));
	}

	@Test
	public void testInvalidDiscount(){
		// given
		Order order = getOrderWithMockedProduct();

		// when

		// then
		assertThrows(IllegalArgumentException.class ,()-> order.setDiscount(BigDecimal.valueOf(1.5)));
		assertThrows(IllegalArgumentException.class, () -> order.setDiscount(BigDecimal.valueOf(-0.2)));
	}

	@Test
	public void testGetDiscount(){
		//given
		Order order = getOrderWithMockedProduct();
		BigDecimal DISCOUNT = BigDecimal.valueOf(0.75);

		//when
		order.setDiscount(DISCOUNT);

		//then
		assertBigDecimalCompareValue(order.getDiscount(),DISCOUNT);
	}

	@Test
	public void testGetProductThroughOrder() {
		// given
		Product expectedProduct = mock(Product.class);
		Order order = new Order(Collections.singletonList(expectedProduct));

		// when
		List<Product> actualProduct = order.getProducts();

		// then
		assertSame(expectedProduct, actualProduct.get(0));
	}

	@Test
	public void testSetShipment() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();
		Shipment expectedShipment = mock(Shipment.class);

		// when
		order.setShipment(expectedShipment);

		// then
		assertSame(expectedShipment, order.getShipment());
	}

	@Test
	public void testShipmentWithoutSetting() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();

		// when

		// then
		assertNull(order.getShipment());
	}

	@Test
	public void testGetPrice() throws Exception {
		// given
		BigDecimal expectedProductPrice = BigDecimal.valueOf(1000);
		Product product = mock(Product.class);
		given(product.getPrice()).willReturn(expectedProductPrice);
		Order order = new Order(Collections.singletonList(product));

		// when
		BigDecimal actualProductPrice = order.getPrice();

		// then
		assertBigDecimalCompareValue(expectedProductPrice, actualProductPrice);
	}

	private Order getOrderWithCertainProductPrice(double productPriceValue) {
		BigDecimal productPrice = BigDecimal.valueOf(productPriceValue);
		Product product = mock(Product.class);
		given(product.getPrice()).willReturn(productPrice);
		return new Order(Collections.singletonList(product));
	}

	private Order getOrderWithCertainProductPrices(List<Double> productPriceValues) {

		return getOrderWithCertainProductPricesAndDiscount(productPriceValues, BigDecimal.valueOf(0));
	}
	private Order getOrderWithCertainProductPricesAndDiscount(List<Double> productPriceValues, BigDecimal discount) {

		List<Product> products = productPriceValues.stream()
				.map(BigDecimal::valueOf)
				.map(val -> {
					Product product = mock(Product.class);
					given(product.getPrice()).willReturn(val.multiply(BigDecimal.valueOf(1).subtract(discount)));
					return product;
				})
				.collect(Collectors.toList());

		return new Order(products);
	}
	@Test
	public void testGetPriceWhenMoreItems() throws Exception {
		// given
		List<Double> prices = new ArrayList<>(Arrays.asList(0.7, 0.5, 0.25));
		Order order = getOrderWithCertainProductPrices(prices);

		// when
		BigDecimal actualProductPrice = order.getPrice();
		BigDecimal expectedProductPrice = prices.stream()
				.map(BigDecimal::valueOf)
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		// then
		assertBigDecimalCompareValue(expectedProductPrice, actualProductPrice);
	}
	@Test
	public  void testOrderPriceWithDiscountedProducts() throws Exception{
		//given
		List<Double> prices = new ArrayList<>(Arrays.asList(1.0, 2.5, 3.5));
		BigDecimal DISCOUNT = BigDecimal.valueOf(0.3);
		Order order = getOrderWithCertainProductPricesAndDiscount(prices, DISCOUNT);

		//when
		BigDecimal actualProductPrice = order.getPrice();
		BigDecimal expectedProductPrice = prices.stream()
				.map(BigDecimal::valueOf)
				.map(val -> val.multiply(BigDecimal.valueOf(1).subtract(DISCOUNT)))
				.reduce(BigDecimal.ZERO, BigDecimal::add);

		//then
		assertBigDecimalCompareValue(actualProductPrice, expectedProductPrice);

	}
	@Test
	public  void testDiscountedOrderPrice() throws Exception{
		//given
		List<Double> prices = new ArrayList<>(Arrays.asList(1.0, 2.5, 3.5));
		Order order = getOrderWithCertainProductPrices(prices);
		BigDecimal orderDiscount = BigDecimal.valueOf(0.2);

		//when
		order.setDiscount(orderDiscount);
		BigDecimal actualProductPrice = order.getPrice();
		BigDecimal expectedProductPrice = prices.stream()
				.map(BigDecimal::valueOf)
				.reduce(BigDecimal.ZERO, BigDecimal::add)
				.multiply(BigDecimal.valueOf(1).subtract(orderDiscount));

		//then
		assertBigDecimalCompareValue(actualProductPrice, expectedProductPrice);

	}
	@Test
	public void testDiscounted_OrderAndProducts_Price() throws Exception{
		//given
		List<Double> prices = new ArrayList<>(Arrays.asList(1.0, 2.5, 3.5));
		BigDecimal productDiscount = BigDecimal.valueOf(0.3);
		Order order = getOrderWithCertainProductPricesAndDiscount(prices,productDiscount);
		BigDecimal orderDiscount = BigDecimal.valueOf(0.2);

		//when
		order.setDiscount(orderDiscount);
		BigDecimal actualProductPrice = order.getPrice();
		BigDecimal expectedProductPrice = prices.stream()
				.map(BigDecimal::valueOf)
				.map(val -> val.multiply(BigDecimal.valueOf(1).subtract(productDiscount)))
				.reduce(BigDecimal.ZERO, BigDecimal::add)
				.multiply(BigDecimal.valueOf(1).subtract(orderDiscount));

		//then
		assertBigDecimalCompareValue(actualProductPrice, expectedProductPrice);
	}

	@Test
	public void testPriceWithTaxesWithoutRoundUp() {
		// given

		// when
		Order order = getOrderWithCertainProductPrice(2); // 2 PLN


		// then
		assertBigDecimalCompareValue(order.getPriceWithTaxes(), BigDecimal.valueOf(2.46)); // 2.46 PLN


	}

	@Test
	public void testPriceWithTaxesWithRoundDown() {
		// given

		// when
		Order order = getOrderWithCertainProductPrice(0.01); // 0.01 PLN
		Order order1 =getOrderWithCertainProductPrice(1.15); //1.15 PLN

		// then
		assertBigDecimalCompareValue(order.getPriceWithTaxes(), BigDecimal.valueOf(0.01)); // 0.01 PLN
		assertBigDecimalCompareValue(order1.getPriceWithTaxes(), BigDecimal.valueOf(1.41)); // 1.15 *1,23 = 1,4145
	}

	@Test
	public void testPriceWithTaxesWithRoundUp() {
		// given

		// when
		Order order = getOrderWithCertainProductPrice(0.03); // 0.03 PLN
		Order order2 = getOrderWithCertainProductPrice(1.11);
		// then
		assertBigDecimalCompareValue(order.getPriceWithTaxes(), BigDecimal.valueOf(0.04)); // 0.04 PLN
		assertBigDecimalCompareValue(order2.getPriceWithTaxes(),BigDecimal.valueOf(1.37)); // 1.11*1.23 = 1.3653
	}

	@Test
	public void testSetShipmentMethod() {
		// given
		Order order = getOrderWithMockedProduct();
		ShipmentMethod surface = mock(SurfaceMailBus.class);

		// when
		order.setShipmentMethod(surface);

		// then
		assertSame(surface, order.getShipmentMethod());
	}

	@Test
	public void testSending() {
		// given
		Order order = getOrderWithMockedProduct();
		SurfaceMailBus surface = mock(SurfaceMailBus.class);
		Shipment shipment = mock(Shipment.class);
		given(shipment.isShipped()).willReturn(true);

		// when
		order.setShipmentMethod(surface);
		order.setShipment(shipment);
		order.send();

		// then
		assertTrue(order.isSent());
	}

	@Test
	public void testIsSentWithoutSending() {
		// given
		Order order = getOrderWithMockedProduct();
		Shipment shipment = mock(Shipment.class);
		given(shipment.isShipped()).willReturn(true);

		// when

		// then
		assertFalse(order.isSent());
	}

	@Test
	public void testWhetherIdExists() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();

		// when

		// then
		assertNotNull(order.getId());
	}

	@Test
	public void testSetPaymentMethod() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();
		PaymentMethod paymentMethod = mock(MoneyTransferPaymentTransaction.class);

		// when
		order.setPaymentMethod(paymentMethod);

		// then
		assertSame(paymentMethod, order.getPaymentMethod());
	}

	@Test
	public void testPaying() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();
		PaymentMethod paymentMethod = mock(MoneyTransferPaymentTransaction.class);
		given(paymentMethod.commit(any(MoneyTransfer.class))).willReturn(true);
		MoneyTransfer moneyTransfer = mock(MoneyTransfer.class);
		given(moneyTransfer.isCommitted()).willReturn(true);

		// when
		order.setPaymentMethod(paymentMethod);
		order.pay(moneyTransfer);

		// then
		assertTrue(order.isPaid());
	}

	@Test
	public void testIsPaidWithoutPaying() throws Exception {
		// given
		Order order = getOrderWithMockedProduct();

		// when

		// then
		assertFalse(order.isPaid());
	}
}
