package pl.edu.agh.internetshop;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static pl.edu.agh.internetshop.util.CustomAssertions.assertBigDecimalCompareValue;

import java.math.BigDecimal;


public class ProductTest {

	
    private static final String NAME = "Mr. Sparkle";
    private static final BigDecimal PRICE = BigDecimal.valueOf(1);
    private static final BigDecimal DISCOUNT = BigDecimal.valueOf(0.3);


	@Test
    public void testProductName() throws Exception{
        //given
    	
        // when
        Product product = new Product(NAME, PRICE,DISCOUNT);
        
        // then
        assertEquals(NAME, product.getName());
    }
    
    @Test
    public void testProductPrice() throws Exception{
        //given
    	BigDecimal discount = BigDecimal.ZERO;
        // when
        Product product = new Product(NAME, PRICE,discount);
        
        // then
        assertBigDecimalCompareValue(product.getPrice(), PRICE);
    }
    @Test
    public void testDiscountNotInRange() throws Exception{
	    //given

        //when

        //then
	    assertThrows(IllegalArgumentException.class, () -> new Product(NAME,PRICE,BigDecimal.valueOf(1.5)));
        assertThrows(IllegalArgumentException.class, () -> new Product(NAME,PRICE,BigDecimal.valueOf(-0.1)));
    }

    @Test
    public void testProductDiscount() throws Exception{
	    //given

        //when
        Product product = new Product(NAME,PRICE,DISCOUNT);

        //then
        assertBigDecimalCompareValue(product.getDiscount(),DISCOUNT);
    }

    @Test
    public void testProductDiscountedPrice() throws Exception{
	    //given

        //when
        Product product = new Product(NAME,PRICE,DISCOUNT);

        //then
        assertBigDecimalCompareValue(product.getPrice(), PRICE.multiply(BigDecimal.valueOf(1).subtract(DISCOUNT)));
    }
}