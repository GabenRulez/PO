package pl.agh.edu.dp.labirynth.factory;

import org.junit.Test;

import static org.junit.Assert.*;

public class MazeFactoryTest {

    @Test
    public void getInstance() {
        MazeFactory factory = MazeFactory.getInstance();
        MazeFactory factory2 = MazeFactory.getInstance();

        assertTrue(factory == MazeFactory.getInstance());
        assertEquals(factory,MazeFactory.getInstance());
        assertEquals(factory, factory2);
    }
}
