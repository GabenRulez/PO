package pl.agh.edu.dp.labirynth.factory;


import pl.agh.edu.dp.labirynth.Door;
import pl.agh.edu.dp.labirynth.Room;
import pl.agh.edu.dp.labirynth.Wall;

public class EnchantedMazeFactory extends MazeFactory {

    private static EnchantedMazeFactory instance = new EnchantedMazeFactory();
    public static EnchantedMazeFactory getInstance(){
        return instance;
    };

    @Override
    public Room createRoom(int number){
        return new EnchantedRoom(number);
    }

    @Override
    public Door createDoor(Room room_1, Room room_2){
        return new EnchantedDoor(room_1, room_2);
    }

    @Override
    public Wall createWall(){
        return new EnchantedWall();
    }
}

