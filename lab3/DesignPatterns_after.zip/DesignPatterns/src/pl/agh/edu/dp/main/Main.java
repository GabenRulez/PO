package pl.agh.edu.dp.main;

import pl.agh.edu.dp.labirynth.*;
import pl.agh.edu.dp.labirynth.builder.StandardMazeBuilder;
import pl.agh.edu.dp.labirynth.factory.MazeFactory;

public class Main {

    public static void main(String[] args) throws Exception {

        MazeGame mazeGame = new MazeGame();
        MazeFactory mazeFactory = new MazeFactory();
        StandardMazeBuilder mazeBuilder = new StandardMazeBuilder(mazeFactory);

        mazeGame.init(mazeBuilder, mazeFactory);
    }
}



