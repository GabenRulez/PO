package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Room;
import pl.agh.edu.dp.labirynth.Wall;

public class BombedMazeFactory extends MazeFactory {

    private static BombedMazeFactory instance = new BombedMazeFactory();
    public static BombedMazeFactory getInstance(){
        return instance;
    };

    @Override
    public Room createRoom(int number){
        return new BombedRoom(number);
    }

    @Override
    public Wall createWall(){
        return new BombedWall();
    }
}
