package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Wall;

public class EnchantedWall extends Wall {

    @Override
    public void Enter(){
        System.out.println("Enchanted Door");
        super.Enter();
    }
}

