package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Room;

public class EnchantedRoom extends Room {

    public EnchantedRoom(int number) {
        super(number);
    }

    @Override
    public void Enter(){
        System.out.println("Enchanted Room");
        super.Enter();
    }
}

