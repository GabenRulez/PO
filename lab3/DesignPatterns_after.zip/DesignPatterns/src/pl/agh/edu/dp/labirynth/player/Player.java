package pl.agh.edu.dp.labirynth.player;

import pl.agh.edu.dp.labirynth.Direction;
import pl.agh.edu.dp.labirynth.Door;
import pl.agh.edu.dp.labirynth.MapSite;
import pl.agh.edu.dp.labirynth.Room;
import pl.agh.edu.dp.labirynth.factory.BombedRoom;
import pl.agh.edu.dp.labirynth.factory.BombedWall;

public class Player {

    private Room currentRoom;
    private int health;

    public Player(Room startingRoom){
        this.currentRoom = startingRoom;
        this.health = 100;
        System.out.println("");
        this.currentRoom.Enter();
    }

    public void move(Direction direction){
        MapSite obiekt = this.currentRoom.getSide(direction);
        obiekt.Enter();
        if(obiekt instanceof Door){
            Room nextRoom = ((Door) obiekt).otherRoom(this.currentRoom);
            nextRoom.Enter();
            this.currentRoom = nextRoom;
        }
        else if(obiekt instanceof BombedWall){
            this.getDamaged(10);
        }
        else if(obiekt instanceof BombedRoom){
            this.getDamaged(10);
        }
    }

    public void getDamaged(int damage){
        this.health -= damage;
    }

    public int getHealth(){
        return this.health;
    }
}
