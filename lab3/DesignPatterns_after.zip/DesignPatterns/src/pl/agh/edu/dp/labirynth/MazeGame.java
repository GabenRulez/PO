package pl.agh.edu.dp.labirynth;

import pl.agh.edu.dp.labirynth.builder.MazeBuilder;
import pl.agh.edu.dp.labirynth.builder.StandardMazeBuilder;
import pl.agh.edu.dp.labirynth.factory.MazeFactory;
import pl.agh.edu.dp.labirynth.player.Player;

import java.util.Scanner;

public class MazeGame {

    private Maze maze;
    private Player player;

    private boolean gameOver = false;
    private Scanner keyboard;

    public void init(StandardMazeBuilder mazeBuilder, MazeFactory mazeFactory) throws Exception{
        this.maze = this.createMaze(mazeBuilder, mazeFactory);
        System.out.println("Created new Maze Game.");

        this.keyboard = new Scanner(System.in);
        System.out.println("Controlls: WASD - movement.");
        System.out.println("L - leave game");

        this.player = new Player(this.maze.getFirstRoom());


        while(!gameOver){
            this.gameLoop();
        }

        System.out.println("Ended the Maze Game.");
    }

    private void gameLoop(){
        System.out.println(" ");    // "spacer", ku poprawie widoczności.
        char buttonPressed = keyboard.next().charAt(0);
        switch(buttonPressed){
            case 'w':
                this.player.move(Direction.North);
                break;
            case 'a':
                this.player.move(Direction.West);
                break;
            case 's':
                this.player.move(Direction.South);
                break;
            case 'd':
                this.player.move(Direction.East);
                break;
            case 'l':
                System.out.println("So you have chosen... Death.");
                this.gameOver = true;
                break;
            default:
                System.out.println("No such control. Try using WASD(movement) or L(lose the game).");
                break;
        }
        if (this.player.getHealth()<=0){
            this.gameOver = true;
            System.out.println("You run out of live. Game over.");
        }
    }

    public Maze createMaze(StandardMazeBuilder mazeBuilder, MazeFactory mazeFactory) throws Exception{

        Room room_1 = new Room(1);
        Room room_2 = new Room(2);
        Room room_3 = new Room(3);

        mazeBuilder.addRoom(room_1);
        mazeBuilder.addRoom(room_2);
        mazeBuilder.addRoom(room_3);

        mazeBuilder.CommonWall(room_1, room_2, Direction.East);
        mazeBuilder.addDoor(room_1, room_2);

        mazeBuilder.CommonWall(room_2, room_3, Direction.North);
        mazeBuilder.addDoor(room_2, room_3);

        return mazeBuilder.getMaze();
    }


}
