package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Wall;

public class BombedWall extends Wall {

    @Override
    public void Enter(){
        System.out.println("Bombed Wall");
        super.Enter();
    }
}

