package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Door;
import pl.agh.edu.dp.labirynth.Room;
import pl.agh.edu.dp.labirynth.Wall;

public class MazeFactory {

    private static MazeFactory instance = new MazeFactory();
    public static MazeFactory getInstance(){
        return instance;
    };


    public Room createRoom(int number){
        return new Room(number);
    }

    public Door createDoor(Room room_1, Room room_2){
        return new Door(room_1, room_2);
    }

    public Wall createWall(){
        return new Wall();
    }
}

