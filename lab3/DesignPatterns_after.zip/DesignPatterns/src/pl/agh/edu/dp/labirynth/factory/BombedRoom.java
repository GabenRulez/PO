package pl.agh.edu.dp.labirynth.factory;

import pl.agh.edu.dp.labirynth.Room;

public class BombedRoom extends Room {

    public BombedRoom(int number) {
        super(number);
    }

    @Override
    public void Enter(){
        System.out.println("Bombed Room");
        super.Enter();
    }
}

