package pl.agh.edu.dp.labirynth;

public enum Direction {
    North, South, East, West
}