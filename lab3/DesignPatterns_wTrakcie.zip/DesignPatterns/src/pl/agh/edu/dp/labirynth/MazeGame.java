package pl.agh.edu.dp.labirynth;

import pl.agh.edu.dp.labirynth.builder.MazeBuilder;
import pl.agh.edu.dp.labirynth.builder.StandardMazeBuilder;

public class MazeGame {
    public Maze createMaze(StandardMazeBuilder mazeBuilder) throws Exception{

        Room room_1 = new Room(1);
        Room room_2 = new Room(2);
        Room room_3 = new Room(3);

        mazeBuilder.addRoom(room_1);
        mazeBuilder.addRoom(room_2);
        mazeBuilder.addRoom(room_3);

        mazeBuilder.CommonWall(room_1, room_2, Direction.East);
        mazeBuilder.addDoor(room_1, room_2);

        mazeBuilder.CommonWall(room_2, room_3, Direction.North);
        mazeBuilder.addDoor(room_2, room_3);

        return mazeBuilder.getMaze();
    }
}
