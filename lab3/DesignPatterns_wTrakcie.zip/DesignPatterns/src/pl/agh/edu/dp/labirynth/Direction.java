package pl.agh.edu.dp.labirynth;

public enum Direction {
    North, South, East, West;

    public Direction oppositeDirection(){
        switch(this){
            case North:
                return South;
            case South:
                return North;
            case East:
                return West;
            case West:
                return East;
            default:
                System.out.println("Nie ma takiego kierunku! - " + this);
                System.out.println("Zwracam North jako defaultowy kierunek.");
                return North;
        }
    }

}

