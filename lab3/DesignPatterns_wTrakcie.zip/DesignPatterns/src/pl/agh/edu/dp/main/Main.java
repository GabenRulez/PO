package pl.agh.edu.dp.main;

import pl.agh.edu.dp.labirynth.*;
import pl.agh.edu.dp.labirynth.builder.StandardMazeBuilder;

public class Main {

    public static void main(String[] args) throws Exception {

        MazeGame mazeGame = new MazeGame();
        Maze maze = mazeGame.createMaze(new StandardMazeBuilder());

        System.out.println(maze.getRoomNumbers());
    }
}



