package pl.agh.edu.dp.labirynth.factory;

public class MazeFactory {
}
