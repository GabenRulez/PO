package pl.agh.edu.dp.labirynth.builder;
import pl.agh.edu.dp.labirynth.*;

public class CountingMazeBuilder implements MazeBuilder {
    private int counter;

    public CountingMazeBuilder(){
        this.counter = 0;
    }

    @Override
    public void addRoom(Room room) {
        this.counter = this.counter + 5;
    }

    @Override
    public void addDoor(Room room_1, Room room_2) throws Exception {
        this.counter++;
    }

    @Override
    public void CommonWall(Room room_1, Room room_2, Direction room_1_direction){
        this.counter--;
    }

    public int GetCounts(){
        return this.counter;
    }
}
