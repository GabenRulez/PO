package pl.agh.edu.dp.labirynth.builder;

import pl.agh.edu.dp.labirynth.*;

public class StandardMazeBuilder implements MazeBuilder {
    private Maze currentMaze;

    public StandardMazeBuilder(){
        this.currentMaze = new Maze();
    }

    @Override
    public void addRoom(Room room) {
        for (Direction direction : Direction.values()){
            room.setSide(direction, new Wall());
        }
        currentMaze.addRoom(room);
    }

    @Override
    public void addDoor(Room room_1, Room room_2) throws Exception {
        Direction room_1_direction = null;
        for (Direction direction : Direction.values()){
            if(room_1.getSide(direction) == room_2.getSide(direction.oppositeDirection()) ){
                room_1_direction = direction;
                break;
            }
        }
        if(room_1_direction == null){
            throw new Exception("Pokoje " + room_1 + " i " + room_2 + ", nie mają wspólnej ściany.");
        }
        else{
            Door door = new Door(room_1, room_2);
            room_1.setSide(room_1_direction, door);
            room_2.setSide(room_1_direction.oppositeDirection(), door);
        }
    }

    @Override
    public void CommonWall(Room room_1, Room room_2, Direction room_1_direction){
        MapSite wall = room_1.getSide(room_1_direction);
        room_2.setSide(room_1_direction.oppositeDirection(), wall);
    }

    public Maze getMaze() {
        return currentMaze;
    }


}
