package Decorator;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class FileDataSource implements  DataSource {
    private final String filename;

    public FileDataSource(String filename){
        this.filename=filename;
    }

    public String getFilename() {
        return filename;
    }

    @Override
    public void writeData(String data) throws IOException, NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException {
        FileWriter fw = new FileWriter(filename);

        fw.write(data);
        fw.close();
    }

    @Override
    public String readData() throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        StringBuilder result = new StringBuilder();
        String line = null;
        while((line = br.readLine()) != null){
                result.append(line);
                result.append("\n");
        }
        br.close();
        return result.toString();
    }
}