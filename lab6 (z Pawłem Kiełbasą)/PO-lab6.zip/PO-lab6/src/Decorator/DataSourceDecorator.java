package Decorator;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class DataSourceDecorator implements DataSource {

    DataSource wrapper;

    public DataSourceDecorator( DataSource wrapper){
        this.wrapper=wrapper;
    }

    @Override
    public void writeData(String data) throws IOException, NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, InvalidKeyException {

    }

    @Override
    public String readData() throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        return null;
    }
}
