package Decorator;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class EncryptionDecorator extends DataSourceDecorator {

    public EncryptionDecorator(DataSource wrapper) {
        super(wrapper);
    }

    private final int multiplier = 3;
    private final int adder = 11;


    @Override
    public void writeData(String data) throws BadPaddingException, NoSuchAlgorithmException, IOException, IllegalBlockSizeException, NoSuchPaddingException, InvalidKeyException {
        wrapper.writeData(
                data.chars()
                        .mapToObj(ch -> (char) ch)
                        .map(character -> character * multiplier + adder)
                        .map(integer ->(char)((int)integer))
                        .collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append)
                        .toString());
    }

    @Override
    public String readData() throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, BadPaddingException, IllegalBlockSizeException, InvalidKeyException {
        return wrapper
                .readData()
                .chars()
                .mapToObj(ch -> (char) ch)
                .map(character -> (character-adder) / multiplier )
                .map(integer ->(char)((int)integer))
                .collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append)
                .toString();
    }
}
