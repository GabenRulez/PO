package Command;

public class UndoCommand extends Command{

    public UndoCommand(Application app, Editor editor){
        super(app, editor);
    }

    @Override
    public void execute() {
        System.out.println("\t--- Operacja cofnięcia ---\t\n");
        this.app.undo();
    }
}

