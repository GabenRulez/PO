package Command;

import java.util.ArrayList;

public class Application {
    public ArrayList<Editor> editors;
    public Editor activeEditor;
    public String clipboard;
    public CommandHistory history;

    public Application(Editor startEditor, String startClipboard){
        this.editors = new ArrayList<Editor>();
        this.addEditor(startEditor);
        this.activeEditor = startEditor;

        this.clipboard = startClipboard;
        this.history = new CommandHistory();
    }

    public void addEditor(Editor editor){
        this.editors.add(editor);
    }

    public void switchEditorToRandom(){
        Editor temp = this.activeEditor;
        if( this.editors.size() < 2 ){
            System.out.println("\t--- Istnieje tylko jeden edytor. ---\t\n");
        }
        else{
            while( temp == this.activeEditor ){
                temp = this.editors.get( (int)(Math.random() * this.editors.size()) );
            }
            this.activeEditor = temp;
            System.out.println(String.format("Został wybrany edytor o zawartości '%s'.", this.activeEditor.getSelection()));
        }
    }

    public void createUI(){
        System.out.println("********************************************************************************");
        System.out.println("Stan aplikacji:");
        for(int i=0; i<this.editors.size(); i++){
            if( this.editors.get(i) == this.activeEditor ){
                System.out.println(String.format("\nEdytor %d - zawartość: (aktywny edytor)\n%s", i, this.editors.get(i).getSelection()));
            }
            else{
                System.out.println(String.format("\nEdytor %d - zawartość: \n%s", i, this.editors.get(i).getSelection()));
            }
        }
        System.out.println(String.format("\nZawartość schowka: \n%s", this.clipboard));
        System.out.println("********************************************************************************\n");
    }

    public void executeCommand(Command c){
        c.execute();
        history.push(c);
    }

    public void undo(){
        Command temp = history.pop();
        if( temp != null ){
            temp.undo();
        }
        else{
            System.out.println("\t--- Nie można cofnąć więcej operacji. ---\t\n");
        }
    }

}
