package Command;

public class CopyCommand extends Command{

    public CopyCommand(Application app, Editor editor){
        super(app, editor);
    }

    @Override
    public void execute() {
        this.app.clipboard = this.editor.getSelection();
        System.out.println("\t--- Operacja kopiowania ---\t\n");
    }
}
