package Command;

import java.util.EmptyStackException;
import java.util.Stack;

public class CommandHistory {

    private Stack<Command> history;

    public CommandHistory(){
        this.history = new Stack<>();
    }

    public void push(Command c){
        this.history.push(c);
    }

    public Command pop(){
        try{
            Command temp = this.history.pop();
            while(temp.backup == null){
                temp = this.history.pop();
            }
            return temp;
        }
        catch(EmptyStackException e){
            return null;
        }
    }
}

