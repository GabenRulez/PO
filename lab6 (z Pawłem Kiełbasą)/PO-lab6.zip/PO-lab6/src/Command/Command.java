package Command;

public abstract class Command {
    protected Application app;      // protected bo private blokuje dostęp klasom dziedziczącym
    protected Editor editor;
    protected String backup;

    public Command(Application app, Editor editor){
        this.app = app;
        this.editor = editor;
        this.backup = null;
    }

    public void saveBackup(){
        this.backup = this.editor.getSelection();
    }

    public void undo(){
        if (this.backup != null) this.editor.replaceSelection(this.backup);
    }

    public void execute(){
        System.out.println("Ta komenda nie ma żadnego zdefiniowanego efektu.");
    }

}
