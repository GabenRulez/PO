package Command;

public class Main {
    public static void main(String[] args) {

        Editor editor_1 = new Editor();
        editor_1.replaceSelection("Kanapki");
        Editor editor_2 = new Editor();
        editor_2.replaceSelection("Banany");
        Editor editor_3 = new Editor();
        editor_3.replaceSelection("AAABBBCCC");

        Application application = new Application(editor_1, "");

        application.addEditor(editor_2);
        application.addEditor(editor_3);

        application.createUI();

        application.executeCommand( new CopyCommand(application, editor_1) );
        application.executeCommand( new PasteCommand(application, editor_2) );
        application.executeCommand( new PasteCommand(application, editor_3) );

        application.createUI();

        application.executeCommand( new UndoCommand(application, editor_2) );
        application.executeCommand( new UndoCommand(application, editor_3) );

        application.createUI();

        application.executeCommand( new CutCommand(application, editor_3) );
        application.executeCommand( new PasteCommand(application, editor_1) );

        application.createUI();

        application.executeCommand( new UndoCommand(application, editor_1) );

        application.createUI();
    }
}
