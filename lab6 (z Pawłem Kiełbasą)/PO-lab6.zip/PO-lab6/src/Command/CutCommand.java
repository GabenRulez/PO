package Command;

public class CutCommand extends Command{

    public CutCommand(Application app, Editor editor){
        super(app, editor);
    }

    @Override
    public void execute() {
        super.saveBackup();
        this.app.clipboard = this.editor.getSelection();
        this.editor.deleteSelection();
        System.out.println("\t--- Operacja wycinania ---\t\n");
    }
}
