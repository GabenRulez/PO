package pl.edu.agh.dronka.shop.model;

public class Music extends Item {

    private GatunekMuzyczny genre;
    private boolean hasVideo;

    // Nazwa, Cena, Ilość, Tanie bo polskie, Używany, Gatunek muzyczny, zTeledyskiem
    public Music(String name, Category category, int price, int quantity, GatunekMuzyczny genre, boolean hasVideo){
        super(name, category, price, quantity);
        this.genre = genre;
        this.hasVideo = hasVideo;
    }

    public GatunekMuzyczny getGenre(){
        return this.genre;
    }

    public boolean hasVideo(){
        return this.hasVideo;
    }

    public Music(){}

    public void setHasVideo(boolean hasVideo){ this.hasVideo = hasVideo; }
}

