package pl.edu.agh.dronka.shop.model;

public enum GatunekMuzyczny {
    POP, ELECTRONIC, CLASSICAL, RAP, ROCK, METAL
}

