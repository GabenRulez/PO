package pl.edu.agh.dronka.shop.model;

import java.util.Date;

public class Food extends Item {

    private Date expireDate;

    // Nazwa, Cena, Ilość, Tanie bo polskie, Używany, DataPrzydatności
    public Food(String name, Category category, int price, int quantity, Date expireDate){
        super(name, category, price, quantity);
        this.expireDate = expireDate;
    }

    public Date getExpireDate(){ return this.expireDate; }

    public Food(){};
}


