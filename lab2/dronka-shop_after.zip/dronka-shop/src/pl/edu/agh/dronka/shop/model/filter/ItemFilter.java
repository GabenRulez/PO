package pl.edu.agh.dronka.shop.model.filter;

import pl.edu.agh.dronka.shop.model.*;

public class ItemFilter {

	private Item itemSpec;

	public ItemFilter(Category category){
		System.out.println(category);
		switch(category){
			case BOOKS:
				itemSpec = new Book();
				break;
			case ELECTRONICS:
				itemSpec = new Electronic();
				break;
			case FOOD:
				itemSpec = new Food();
				break;
			case MUSIC:
				itemSpec = new Music();
				break;
			case SPORT:
				itemSpec = new Sport();
				break;
			default:
				itemSpec = new Item();
				break;
		}
	}





	public Item getItemSpec() {
		return itemSpec;
	}
	public boolean appliesTo(Item item) {
		if (itemSpec.getName() != null
				&& !itemSpec.getName().equals(item.getName())) {
			return false;
		}
		if (itemSpec.getCategory() != null
				&& !itemSpec.getCategory().equals(item.getCategory())) {
			return false;
		}

		// applies filter only if the flag (secondHand) is true)
		if (itemSpec.isSecondhand() && !item.isSecondhand()) {
			return false;
		}

		// applies filter only if the flag (polish) is true)
		if (itemSpec.isPolish() && !item.isPolish()) {
			return false;
		}


		/* Moja część */
		if(itemSpec instanceof Book){
			if( ((Book) itemSpec).hasHardCover() && !((Book) item).hasHardCover() ){
				return false;
			}
		}

		if(itemSpec instanceof Electronic){
			if( ((Electronic) itemSpec).isMobile() && !((Electronic) item).isMobile() ){
				return false;
			}
			if( ((Electronic) itemSpec).hasGuarantee() && !((Electronic) item).hasGuarantee() ){
				return false;
			}
		}

		if(itemSpec instanceof Music){
			if( ((Music) itemSpec).hasVideo() && !((Music) item).hasVideo() ){
				return false;
			}
		}

		/* Koniec mojej części */


		return true;
	}

}