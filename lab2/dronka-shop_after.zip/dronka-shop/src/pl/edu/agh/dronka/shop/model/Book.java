package pl.edu.agh.dronka.shop.model;

public class Book extends Item {

    private int howManyPages;
    private boolean hardCover;

    // Nazwa, Cena, Ilość, Tanie bo polskie, Używany, Liczba stron, Twarda oprawa
    public Book(String name, Category category, int price, int quantity, int howManyPages, boolean hardCover){
        super(name, category, price, quantity);
        this.howManyPages = howManyPages;
        this.hardCover = hardCover;
    }

    public int getHowManyPages(){ return this.howManyPages; }

    public boolean hasHardCover(){ return this.hardCover; }

    public Book(){}

    public void setHardCover(boolean set){ this.hardCover = set; }
}



