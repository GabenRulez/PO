package pl.edu.agh.dronka.shop.model;

public class Electronic extends Item {

    private boolean isMobile;
    private boolean hasGuarantee;

    // Nazwa, Cena, Ilość, Tanie bo polskie, Używany, Mobilny, Gwarancja
    public Electronic(String name, Category category, int price, int quantity, boolean isMobile, boolean hasGuarantee){
        super(name, category, price, quantity);
        this.isMobile = isMobile;
        this.hasGuarantee = hasGuarantee;
    }

    public boolean isMobile(){
        return this.isMobile;
    }

    public boolean hasGuarantee(){
        return this.hasGuarantee;
    }

    public Electronic(){}

    public void setIsMobile(boolean isMobile){this.isMobile = isMobile;}
    public void setHasGuarantee(boolean hasGuarantee){this.hasGuarantee = hasGuarantee;}
}


